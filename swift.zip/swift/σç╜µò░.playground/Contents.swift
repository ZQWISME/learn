
func about() -> Void{
    print("iphone xs max")
}
func about1() -> () {
    print("iphone Xs Max")
}
func about2() {
    print("iphone Xs Max")
}
func sum(a:Int,b:Int) -> Int{
    let totle = a + b
    return totle
}
let totle = sum(a: 10, b: 20)
print(totle)

//返回值为复杂类型(元组)
import Foundation
func Gg(info:String) -> (name:String,age:Int) {
    
    let infos = info.components(separatedBy: ",")
    return(infos[0],Int(infos[1])!)
}
let ff = Gg(info: "zhansan,12")
func GG(info:String) -> (No:Int,menu:String) {
    let menus = info.components(separatedBy: ",")
    return (Int(menus[0])!,menus[1])
}
 //
 //
 //
 //参数标签与参数名
func sum1(_ num1:Int = 10,_ num2:Int = 10) -> Int {
    return num1 * num2
}
sum1()
sum1(20,30)

//inout 关键字
func GG(a:inout Int,b:inout Int) {
    let c = a
    a = b
    b = c
}
var a = 10
var b = 20
print("a=\(a)---b=\(b)")
GG(a: &a, b: &b)
print("a=\(a)---b=\(b)")




func summit(a:Int , b:Int) -> Int{
    return a * b
}
 var RR : (Int, Int) -> Int = summit
  RR(10,20)
  RR = sum1
  RR(10,20)


func sum2(a:Int,b:Int,c:(Int, Int)->Int){
    print(c(a,b))
    
}
sum2(a:10, b:20 , c:summit)
sum2(a:10, b:20 , c:sum1)
