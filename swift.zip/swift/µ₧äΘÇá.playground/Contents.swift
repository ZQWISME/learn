//: Playground - noun: a place where people can play
//构造函数和自定义构造函数可以同时存在
class person{
    var name:String
    var age:Int
    var sex:String
    init() {
        self.name = "zhangsan"
        self.age = 20
        self.sex = "man"
    }
    init(name:String , age:Int , sex:String) {
        self.name = name
        self.age = age
        self.sex = sex
    }
}

var p2 = person(name: "lisi", age: 20, sex: "women")

p2.name
p2.age
p2.sex

var p1 = person()
p1.age
p1.name
p1.sex

//类类型的构造函数委托
class Car{
    //指定构造函数
    var Speed:Double
    init(Speed:Double) {
        self.Speed = Speed
    }
    //便捷构造函数
    convenience init() {
        self.init(Speed: 10.0)
    }
}
class Bus: Car {
    var Wheel:Double
     init(Wheel:Double){
        self.Wheel = Wheel
        super.init(Speed: 11.0)
    }
    convenience init() {
        self.init(Wheel: 6.0)
    }
}


