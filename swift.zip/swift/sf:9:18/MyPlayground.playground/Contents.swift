

//if
//switch
var score = 75
switch score {
case 90...100:
    print("优秀")
case 80..<90:
    print("良好")
case 70...80:
    print("中等")
case 60...70:
    print("及格")
default:
    print("不及格")
}

var age:Int?
//age=10
if let age = age {
    print(age)
}

func optionAge(){
    guard let age = age else
    {
        print("OPTION AGE")
        return
        
    }
    print(age)
}

optionAge()
func online(age:Int){
    guard age == 10 else {
        print("sadads")
        return
    }
    print("else")
}
online(age: 10)
