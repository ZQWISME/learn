//: Playground - noun: a place where people can play

import UIKit

//可变 变量
var uo = "dada"
//不可变 常量
let on = "deta"
//var str = "Hello, playground"
var d:UInt = 18
let i = (ID:123,Name:"zhsda",Sex:"man",age:18)
print(i.age)
// 
let dic = ["ID":"231","Name":"bi"]
for (key,value) in dic{
    print("\(key)--\(value)")
}
var num1 = 10
var num2 = 20
var num = num1 == num2

//布尔型
 var cons1 = true
 var cons2 = false
//或与非
print(!cons1)
print(cons1 && cons2)
print(cons1 || cons2)
//区间运算符
for i in 0...9{
    print(i)
}
print("---------")
for i in 0..<9{
    print(i)
}
