//: Playground - noun: a place where people can play
//扩展计算属性
extension Double{
    var km:Double {return self * 1000.0}
    var M:Double {return self}
    var Cm:Double { return self / 100.0}
    var Mm:Double { return self / 1000.0}
    var Fm:Double {return self / 3.28048}
    
}
var one = 3.0.km
one = 3.0.M
one = 3.0.Cm
one = 3.0.Mm
one = 3.0.Fm

//扩展方法
extension Int {
    func replay(task:() -> Void){
        for _ in 0..<self {
            task()
        }
    }
}
3.replay {
    print("hello world")
}
//扩展mutating方法
extension Double{
    mutating func sss()->Double{
        return self*self
    }
}

var  a = 10.0
a.sss()

