//: Playground - noun: a place where people can play

enum peroson{
    case zhangsan
    case lisi
    case wangwu
    case www
}

let p1 = peroson.www

enum peroson2{
    case xzhan,lisi,wanwu,www
}
let p2 = peroson2.lisi

enum sss:String{
    case zhangsan = "1"
    case lisi = "2"
    case wangwu = "3"
    case www = "4"

}
enum www:Int{
    case zhangsan = 1
    case lisi = 2
    case wangwu = 3
    case www = 4
}

let pp2 = www.lisi
switch pp2 {
case .zhangsan:
    print("1")
case .lisi:
    print("2")
case .wangwu:
    print("3")
case .www:
    print("4")
//default:
//    print("default")
}
let ppp3:sss = .lisi
switch ppp3 {
case .zhangsan:
    print("1")
default:
    print("defalut")
}

enum abc:Int{
    case jj = 1
    case gg = 2
    case ff = 3
    case dd = 4
}
let aa:abc = .jj

switch aa{
case .gg:
    print("2")
case .jj:
    print("7")
case .ff:
    print("3")
case .dd:
    print("4")
    
}
