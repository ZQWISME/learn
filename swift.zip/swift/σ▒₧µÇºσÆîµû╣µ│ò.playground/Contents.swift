//: Playground - noun: a place where people can play

class student{
    //存储属性
    var age:Int = 10
    //属性观察器
    var name:String?{
        willSet{
            if  let newValue = newValue {
                print(newValue)
            }
            
        }
        didSet{
            if let oldValue = oldValue {
                print(oldValue)
            }
        }
    }
    
    var chineseScore:Double = 90.9
    var englishScore:Double = 80.9
    
    //只读计算属性
    var avgscore:Double {
        get{
            return (chineseScore+englishScore)/2
        } 
    }
    //类属性
    static var mathscore:Double = 99.0
    //懒加载
    lazy var teacher:[String] = {
        ()->[String] in
        return ["zzz","sss","qqqq"]
    }()
}
var stu = student()
stu.avgscore
student.mathscore
stu.teacher
stu.teacher
stu.teacher


class studentsss:student {
    
}
var stu1 = studentsss()
stu1.age = 20;

class Student2{
    var str = "hello world"
    
    func say(info:String){
        print(info)
        self.str = "hello , Swift"
    }
    func eat(food:String){
        print("吃\(food)")
    }
}
//值类型默认情况下，不能在实例方法中修改属性
//不能用self调用其他的函数需加上mutating关键词
struct Student3{
    var str = "hello world"
   mutating func say(info:String){
        print(info)
        self.str = "hello , Swift"
    }
    func eat(food:String){
        print("吃\(food)")
    }
}




