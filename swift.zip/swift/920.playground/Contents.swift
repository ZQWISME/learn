//: Playground - noun: a place where people can play
for index in 0...30 {
    print("Hello World")
    if index == 5{
        break
    }
}
for index in 0...30 {
    print("\(index)--Hello World")
    if index == 5{
        continue
    }
}
var A = 10

while A == 10 {
    print("World")
    A = A+1
}

var i = 0
repeat{
    print("repeat while")
    i+=1
}while i<10


