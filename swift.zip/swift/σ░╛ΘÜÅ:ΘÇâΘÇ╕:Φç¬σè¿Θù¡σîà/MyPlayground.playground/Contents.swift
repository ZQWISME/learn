//: Playground - noun: a place where people can play


//var str = "Hello, playground"
//尾随闭包 闭包为函数最后一个参数
func myclos(info:String,closer:(String)->Void){
    closer(info)
}
myclos(info: "Hello World") { (s) in
    print(s)
}
myclos(info: "Hello Swift", closer:{(s) in print(s)})



var closerArray:[()-> Void] = [()->Void]()
func nonEscapeClosure(closer:()->Void){
    closer()
}
//逃逸闭包 @escaping关键字
func Escapecloser(closer:@escaping ()->Void){
    print("闭包调用之前")
    closerArray.append(closer)
    print("闭包调用之后")
}
var x = 10

nonEscapeClosure {
    x = 100
}
print(x)
Escapecloser {
    x = 200
}
print(x)
closerArray.first?()
print(x)

//自动闭包 @sutoclosure关键字
func printIfTure(printer:@autoclosure()->Bool){
    if printer() {
        print("is ture")
    }
    else {
        print("is false")
    }
}
printIfTure(printer: 2>1)
