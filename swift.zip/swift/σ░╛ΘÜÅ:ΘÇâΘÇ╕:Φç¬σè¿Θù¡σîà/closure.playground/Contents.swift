//: Playground - noun: a place where people can play

let result = {
    (num1:Int , num2:Int) -> Int in
    return num1 * num2
}
let b = result(10,20)

let ssclosure = {
    (num:Int) ->Int in
    return  num * num
}

let a = ssclosure (35)

func score(sss:[Int],scor:(Int) ->Bool )->[Int]{
    
    var newscore:[Int] = [Int]()
    for item in sss {
        if  scor(item){
            newscore.append(item)
        }
    }
    return newscore
}

let c = [75,65,85,95]
var d = score(sss: c, scor:{(s:Int)->Bool in return s>80})
var dd = score(sss: c, scor: {(s) in s>80})
var ddd = score(sss: c, scor: {(s:Int) in return s > 80})
print("\(d)")
print("\(dd)")
print("\(ddd)")   

