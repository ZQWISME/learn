//: Playground - noun: a place where people can play
import Foundation

protocol myprotocol{
    var Name:String{get set}
    var Age:Int{get}
    func feed(food:String)
    mutating func shout(sound:String)
}
class Cat: myprotocol {
    var Name: String = "miao"
    
    var Age: Int = 3
    
    func feed(food: String = "mai") {
        
    }
    
    func shout(sound: String = "miaomiao") {

    }
    
}
struct Dog: myprotocol {
    var Name: String
    
    var Age: Int
    
    func feed(food: String = "liang") {
        
    }
    
   mutating func shout(sound: String = "wangwang") {
        self.Name = "dahuang"
        self.Age = 4
    }
}
 // @objc 协议中部分方法的实现
@objc protocol sport{
    func playbasektbal()
    @objc optional func playball()
}
class bb: sport {
    func playbasektbal() {
    }
    
}
//扩展协议
 protocol sport2{
    func playbasektbal()
    func playfootball()
}
extension sport2{
    func playbasektbal() {
    }
}

class dd: sport2 {
    func playfootball() {
        
    }
    

}

//代理
protocol buyTick{
    func buy()
}
class Assit: buyTick {
    func buy() {
        print("秘书去买票")
    }
}
class HN: buyTick {
    func buy() {
        print("黄牛去买票")
    }
}


class boss{
   var degelater:buyTick
    init(degelater:buyTick) {
        self.degelater = degelater
    }
    func GoToBJ(){
        self.degelater.buy()
    }
}
