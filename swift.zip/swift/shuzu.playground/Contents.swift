//: Playground - noun: a place where people can play

var array1 = [String](arrayLiteral: "123","lisi","移互171","man")

var array2  = Array(arrayLiteral: "234","zhansang","13","man")

var a = array1.count
var b = array2.count

array1.isEmpty
array2.isEmpty
