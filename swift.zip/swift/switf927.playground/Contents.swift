//: Playground - noun: a place where people can play
//字典的定义
var dic1 : [ String : Any ] = ["ID":"12345","name":"zhangsan"]
var dic11 : Dictionary = ["ID":"12345","name":"zhangsan"]
var dic22 = Dictionary<String,String>()

//字典长度
dic1.count
dic22.count
//判断是否为空
dic1.isEmpty
dic22.isEmpty

dic11.removeValue(forKey: "ID")
dic22["name"] = "lisi"
print(dic22)

dic1["ID"] = "54321"
print(dic1)

dic11.updateValue("移动互联应用技术171", forKey: "class")
print(dic11)

dic11["ID"]

for key in dic1 {
    print(key)
}
for value in dic1 {
    print(value)
}
for (key,value) in dic1 {
    print("\(key)-----\(value)")
}
for (index,value) in dic1.enumerated() {
    print("\(index)----\(value)")
}
